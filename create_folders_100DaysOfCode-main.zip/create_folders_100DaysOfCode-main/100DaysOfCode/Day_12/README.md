# Day 12

## Things I Learned

