# Day 42

## Things I Learned

