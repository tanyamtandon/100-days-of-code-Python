# Day 57

## Things I Learned

