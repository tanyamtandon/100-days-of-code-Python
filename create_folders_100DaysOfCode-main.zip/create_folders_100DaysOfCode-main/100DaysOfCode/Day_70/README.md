# Day 70

## Things I Learned

