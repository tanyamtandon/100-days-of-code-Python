# Day 72

## Things I Learned

