# Day 80

## Things I Learned

