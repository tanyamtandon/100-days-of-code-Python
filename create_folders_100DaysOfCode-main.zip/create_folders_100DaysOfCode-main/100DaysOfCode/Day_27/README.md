# Day 27

## Things I Learned

