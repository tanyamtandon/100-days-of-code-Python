# Day 52

## Things I Learned

