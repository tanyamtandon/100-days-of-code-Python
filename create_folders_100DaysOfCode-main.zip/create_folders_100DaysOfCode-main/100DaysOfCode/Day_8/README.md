# Day 8

## Things I Learned

