# Day 17

## Things I Learned

