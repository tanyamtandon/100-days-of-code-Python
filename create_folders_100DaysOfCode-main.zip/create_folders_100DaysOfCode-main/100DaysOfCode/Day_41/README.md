# Day 41

## Things I Learned

