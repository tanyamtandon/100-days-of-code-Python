# Day 19

## Things I Learned

