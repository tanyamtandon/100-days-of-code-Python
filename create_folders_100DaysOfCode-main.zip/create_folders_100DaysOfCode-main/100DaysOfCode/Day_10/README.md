# Day 10

## Things I Learned

