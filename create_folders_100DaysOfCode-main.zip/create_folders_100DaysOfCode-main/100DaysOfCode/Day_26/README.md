# Day 26

## Things I Learned

