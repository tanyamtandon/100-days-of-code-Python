# Day 92

## Things I Learned

