# Day 16

## Things I Learned

