# Day 25

## Things I Learned

