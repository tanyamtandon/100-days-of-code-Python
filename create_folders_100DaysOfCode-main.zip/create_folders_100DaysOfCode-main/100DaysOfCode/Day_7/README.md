# Day 7

## Things I Learned

