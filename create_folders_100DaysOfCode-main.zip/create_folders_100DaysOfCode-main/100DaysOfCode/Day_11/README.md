# Day 11

## Things I Learned

