# Day 9

## Things I Learned

