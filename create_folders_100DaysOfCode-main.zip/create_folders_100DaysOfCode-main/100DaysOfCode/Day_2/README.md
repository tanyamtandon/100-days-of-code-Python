# Day 2

## Things I Learned

