# Day 3

## Things I Learned

