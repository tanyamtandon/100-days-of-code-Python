# Day 31

## Things I Learned

