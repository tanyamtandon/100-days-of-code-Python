# Day 33

## Things I Learned

