# Day 18

## Things I Learned

