# Day 69

## Things I Learned

