# Day 45

## Things I Learned

