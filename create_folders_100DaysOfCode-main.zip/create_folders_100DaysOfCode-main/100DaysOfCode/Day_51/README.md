# Day 51

## Things I Learned

