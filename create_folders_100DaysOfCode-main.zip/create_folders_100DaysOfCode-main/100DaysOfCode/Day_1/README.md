# Day 1

## Things I Learned

