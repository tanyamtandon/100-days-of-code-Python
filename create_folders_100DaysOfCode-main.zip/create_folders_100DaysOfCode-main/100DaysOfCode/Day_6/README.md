# Day 6

## Things I Learned

