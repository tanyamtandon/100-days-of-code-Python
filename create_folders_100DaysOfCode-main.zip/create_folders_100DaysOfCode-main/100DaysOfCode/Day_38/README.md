# Day 38

## Things I Learned

