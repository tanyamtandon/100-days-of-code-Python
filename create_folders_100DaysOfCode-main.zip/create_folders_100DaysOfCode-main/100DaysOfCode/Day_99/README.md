# Day 99

## Things I Learned

