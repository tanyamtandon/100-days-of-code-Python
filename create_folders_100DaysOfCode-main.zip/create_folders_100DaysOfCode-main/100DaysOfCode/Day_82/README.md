# Day 82

## Things I Learned

