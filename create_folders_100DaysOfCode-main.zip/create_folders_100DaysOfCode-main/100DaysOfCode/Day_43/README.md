# Day 43

## Things I Learned

