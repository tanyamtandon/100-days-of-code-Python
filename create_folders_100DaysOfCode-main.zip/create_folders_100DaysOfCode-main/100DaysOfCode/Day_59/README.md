# Day 59

## Things I Learned

