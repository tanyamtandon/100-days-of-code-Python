# Day 21

## Things I Learned

