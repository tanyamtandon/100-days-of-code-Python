# Day 73

## Things I Learned

