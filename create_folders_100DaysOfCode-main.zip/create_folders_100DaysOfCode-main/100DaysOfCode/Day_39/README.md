# Day 39

## Things I Learned

