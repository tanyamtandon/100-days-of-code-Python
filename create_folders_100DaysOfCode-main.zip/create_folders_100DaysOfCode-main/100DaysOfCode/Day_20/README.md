# Day 20

## Things I Learned

