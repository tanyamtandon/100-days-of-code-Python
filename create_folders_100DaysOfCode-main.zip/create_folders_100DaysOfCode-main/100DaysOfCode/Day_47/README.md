# Day 47

## Things I Learned

