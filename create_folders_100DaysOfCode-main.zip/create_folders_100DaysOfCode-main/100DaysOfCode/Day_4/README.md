# Day 4

## Things I Learned

