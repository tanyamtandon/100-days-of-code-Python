# Day 36

## Things I Learned

