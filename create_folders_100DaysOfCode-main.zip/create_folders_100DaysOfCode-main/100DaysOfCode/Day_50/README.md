# Day 50

## Things I Learned

