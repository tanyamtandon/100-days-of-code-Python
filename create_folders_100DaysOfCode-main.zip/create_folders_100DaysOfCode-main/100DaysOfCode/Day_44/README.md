# Day 44

## Things I Learned

