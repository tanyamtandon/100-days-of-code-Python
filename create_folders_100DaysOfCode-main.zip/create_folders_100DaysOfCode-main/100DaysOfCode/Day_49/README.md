# Day 49

## Things I Learned

