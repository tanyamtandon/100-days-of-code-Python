# Day 83

## Things I Learned

