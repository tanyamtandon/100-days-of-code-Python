# Day 95

## Things I Learned

