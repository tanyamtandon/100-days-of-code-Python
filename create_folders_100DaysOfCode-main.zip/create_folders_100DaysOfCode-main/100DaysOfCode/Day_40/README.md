# Day 40

## Things I Learned

