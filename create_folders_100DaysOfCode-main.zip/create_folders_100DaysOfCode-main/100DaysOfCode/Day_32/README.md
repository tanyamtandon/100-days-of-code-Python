# Day 32

## Things I Learned

