# Day 24

## Things I Learned

