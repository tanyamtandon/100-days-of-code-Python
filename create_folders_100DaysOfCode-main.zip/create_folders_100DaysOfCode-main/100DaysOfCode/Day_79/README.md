# Day 79

## Things I Learned

