# Day 22

## Things I Learned

