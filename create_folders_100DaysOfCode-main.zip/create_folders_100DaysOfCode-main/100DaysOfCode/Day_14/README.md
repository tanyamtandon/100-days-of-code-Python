# Day 14

## Things I Learned

