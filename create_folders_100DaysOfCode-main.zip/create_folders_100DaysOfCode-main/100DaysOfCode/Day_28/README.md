# Day 28

## Things I Learned

