# Day 89

## Things I Learned

