# Day 23

## Things I Learned

