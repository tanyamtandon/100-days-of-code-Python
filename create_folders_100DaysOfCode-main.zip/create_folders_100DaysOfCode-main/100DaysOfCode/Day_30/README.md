# Day 30

## Things I Learned

