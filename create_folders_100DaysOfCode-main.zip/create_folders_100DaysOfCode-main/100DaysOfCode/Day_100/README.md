# Day 100

## Things I Learned

