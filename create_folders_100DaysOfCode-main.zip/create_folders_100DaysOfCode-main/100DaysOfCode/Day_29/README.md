# Day 29

## Things I Learned

