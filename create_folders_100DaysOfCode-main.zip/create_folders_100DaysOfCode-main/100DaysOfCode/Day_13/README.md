# Day 13

## Things I Learned

