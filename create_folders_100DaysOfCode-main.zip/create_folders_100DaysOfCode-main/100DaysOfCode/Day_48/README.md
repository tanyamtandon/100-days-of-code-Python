# Day 48

## Things I Learned

