# Day 66

## Things I Learned

