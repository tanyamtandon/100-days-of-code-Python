# Day 35

## Things I Learned

