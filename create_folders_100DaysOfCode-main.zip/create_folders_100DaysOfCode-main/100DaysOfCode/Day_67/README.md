# Day 67

## Things I Learned

