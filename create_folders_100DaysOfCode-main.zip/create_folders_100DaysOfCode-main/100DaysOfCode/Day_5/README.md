# Day 5

## Things I Learned

