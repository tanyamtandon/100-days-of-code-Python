# Day 15

## Things I Learned

