# Day 34

## Things I Learned

